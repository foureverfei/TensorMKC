function [F P R nmi avgent AR ACC P_hat error z_tensor_final pred] = func_CATFAT_Bio(data, dis_weight_mat, gt,data_name,opts)
%FUNC_DIFFM_TENSOR_TUCKER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    error = 0;
    lambda = 0.04;
    beta = 0.04;
    projev = 1.5;
    eplison = 1e-5;
    if isfield(opts, 'lambda');         lambda = opts.lambda;     end
    if isfield(opts, 'projev');         projev = opts.projev;     end
    if isfield(opts, 'beta');           beta = opts.beta;     end
    X1=data;
    data = {};
    data{1} = X1;
    ratio=1;
    sigma(1)=ratio*optSigma(X1);   %����֮�������ֵ
    cls_num = length(unique(gt));
    numClust = cls_num;
    num_views = 4;

    %%
    % dataset='COIL20_3VIEWS.mat';
    % dataset='COIL20_3VIEWS.mat';
    % numClust=20;
    % num_views=3;
    % load(dataset);
    % gt=Y;
    % clear Y
    %
    % data{1} = X1;
    % ratio=1;
    % sigma(1)=ratio*optSigma(X1);   %����֮�������ֵ
    % cls_num = length(unique(gt));

    tic
    %% Construct kernel and transition matrix
    K=[];
    T=cell(1,num_views);
    dis_method = {'Gaussian','Polynomial','PolyPlus','Linear'};
    
    
    
    
    %dis_method = {'Gaussian','Gaussian','Gaussian','Gaussian'};
    for j=1:length(dis_method)
        options.KernelType = dis_method{j};
        options.t = sigma(1);
        K(:,:,j) = constructKernel(data{1},data{1},options);
        K(:,:,j) = K(:,:,j) .* dis_weight_mat;
        D=diag(sum(K(:,:,j),2));
%         L_rw=D^-1*K(:,:,j);
%         T{j}=L_rw;
        L_rw=D^-0.5*K(:,:,j)*D^-0.5;
        T{j}=L_rw;
    end
    T_tensor = cat(3, T{:,:});
    data_num = size(T_tensor,1);
    t = T_tensor(:);

    %% init evaluation result
    best_single_view.nmi=0;
    feature_concat.nmi=0;
    kernel_addition.nmi=0;
    markov_mixture.nmi=0;
    co_reg.nmi=0;
    markov_ag.nmi=0;

    V = length(T);
    N = size(data{1},1); % number of samples

    for k=1:V
        Z{k} = zeros(N,N);
        Y{k} = zeros(N,N);
        E{k} = zeros(N,N);
    end
    Z_tensor = cat(3, Z{:,:});
    E_tensor = cat(3, E{:,:});

    y = zeros(N*N*V,1);
    dim1 = N;dim2 = N;dim3 = V;
    myNorm = 'tSVD_1';
    sX = [N, N, V];

    %tol = 1e-6;
    tol = 1e-6;
    tol2=1e-7;
    iter = 0;
    mu = 10e-3;
    max_mu = 10e10;
    pho_mu = 2;
    max_iter=15;
    iter_2 = 0;
    max_iter_2 = 50;
    z = zeros(data_num,data_num,4);


    mu_t = mu;
    while iter_2 < max_iter_2
        if iter_2 == 0
            %g = zeros(data_num*data_num*4,1);
            g = cat(3, Y{:,:});
            z_t = Z_tensor;
            while iter < max_iter
                Zpre=Z_tensor;
                Epre=E_tensor;
                fprintf('----processing iter %d--------\n', iter+1);
                %% update Z
                Y_tensor = cat(3, Y{:,:});
                y = Y_tensor(:);
                e = E_tensor(:);

                [z, objV] = wshrinkObj(t - e + 1/mu*y,1/mu,sX,0,3)   ;
                Z_tensor = reshape(z, sX);
                Z{1}=Z_tensor(:,:,1);
                Z{2}=Z_tensor(:,:,2);
                Z{3}=Z_tensor(:,:,3);
                Z{4}=Z_tensor(:,:,4);
                %% update E
                F = [T{1}-Z{1}+Y{1}/mu;T{2}-Z{2}+Y{2}/mu;T{3}-Z{3}+Y{3}/mu;T{4}-Z{4}+Y{4}/mu];
                [Econcat] = solve_l1l2(F,lambda/mu);

                E{1} = Econcat(1:size(T{1},1),:);
                E{2} = Econcat(size(T{1},1)+1:size(T{1},1)+size(T{2},1),:);
                E{3} = Econcat(size(T{1},1)+size(T{2},1)+1:size(T{1},1)+size(T{2},1)+size(T{3},1),:);
                E{4} = Econcat(size(T{1},1)+size(T{2},1)+size(T{3},1)+1:end,:);
                E_tensor = cat(3, E{:,:});

                for k=1:V
                    Y{k} = Y{k} + mu*(T{k}-Z{k}-E{k});
                end

                %% check convergence
                leq = T_tensor-Z_tensor-E_tensor;
                leqm = max(abs(leq(:)));
                difZ = max(abs(Z_tensor(:)-Zpre(:)));
                difE = max(abs(E_tensor(:)-Epre(:)));
                err = max([leqm,difZ,difE]);
                fprintf('iter = %d, mu = %.3f, difZ = %.3f, difE = %.8f,err=%d\n'...
                    , iter,mu,difZ,difE,err);
                if err < tol 
                    break;
                end

                iter = iter + 1;
                mu = min(mu*pho_mu, max_mu);
            end
            iter_2 = iter_2 + 1;
            continue;


        else
            z_t = Z_tensor;
            z_tensor_2 = tensor(Z_tensor);
            Y_Tucker = tucker_als(z_tensor_2,[data_num,data_num,1]);
            A2 = Y_Tucker.core;
            %kron_core = kron(core,core);
            U1 = Y_Tucker.U{1};
            U2 = Y_Tucker.U{2};
            U3 = Y_Tucker.U{3};
            G = double(ttm(Y_Tucker.core,{U1 U2 U3},[1 2 3]));
            g = G(:);
        end
        iter = 1;
        while iter < max_iter
            Zpre=Z_tensor;
            Epre=E_tensor;
            fprintf('----processing iter %d--------\n', iter+1);
            %% update Z
            Y_tensor = cat(3, Y{:,:});
            y = Y_tensor(:);
            e = E_tensor(:);
            delta_h = (mu*(t-e+1/mu*y)+beta*g)/(mu+beta);
            tlambda = 1/(mu+beta);
            %[z, objV] = wshrinkObj(t - e + 1/mu*y,1/mu,sX,0,3)   ;
            [z, objV] = wshrinkObj(delta_h,tlambda,sX,0,3)   ;
            Z_tensor = reshape(z, sX);
            Z{1}=Z_tensor(:,:,1);
            Z{2}=Z_tensor(:,:,2);
            Z{3}=Z_tensor(:,:,3);
            Z{4}=Z_tensor(:,:,4);
            %% update E
            F = [T{1}-Z{1}+Y{1}/mu;T{2}-Z{2}+Y{2}/mu;T{3}-Z{3}+Y{3}/mu;T{4}-Z{4}+Y{4}/mu];
            [Econcat] = solve_l1l2(F,lambda/mu);

            E{1} = Econcat(1:size(T{1},1),:);
            E{2} = Econcat(size(T{1},1)+1:size(T{1},1)+size(T{2},1),:);
            E{3} = Econcat(size(T{1},1)+size(T{2},1)+1:size(T{1},1)+size(T{2},1)+size(T{3},1),:);
            E{4} = Econcat(size(T{1},1)+size(T{2},1)+size(T{3},1)+1:end,:);
            E_tensor = cat(3, E{:,:});

            for k=1:V
                Y{k} = Y{k} + mu*(T{k}-Z{k}-E{k});
            end

            %% check convergence
            leq = T_tensor-Z_tensor-E_tensor;
            leqm = max(abs(leq(:)));
            difZ = max(abs(Z_tensor(:)-Zpre(:)));
            difE = max(abs(E_tensor(:)-Epre(:)));
            err = max([leqm,difZ,difE]);
            fprintf('inside loop:iter = %d, mu = %.3f, difZ = %.3f, difE = %.8f,err=%d\n'...
                , iter,mu,difZ,difE,err);
            if err < tol
                break;
            end


            iter = iter + 1;
            mu = min(mu*pho_mu, max_mu);


            S = zeros(N,N);
            for k=1:num_views
                S = S + Z{k};
            end
            S(S<0) = S(S<0) +eplison;
            [pi,~]=eigs(S',1);                 %largest eigenvector
            Dist=pi/sum(pi);
            pi=diag(Dist);                    %L'
            P_hat=(pi^0.5*S*pi^-0.5+pi^-0.5*S'*pi^0.5)/2;

            if isreal(P_hat) == 0
                continue;
            end
            % toc
%             fprintf(data_name)
% 
%             [pred] = SpectralClustering(P_hat, numClust);
%             [F P R nmi avgent AR ACC] = baseline_acc(pred,gt);
%             fprintf('ELMSC spectralClustering  :F=%f, P=%f, R=%f, nmi score=%f, avgent=%f,  AR=%f, ACC=%f,\n',F(1),P(1),R(1),nmi(1),avgent(1),AR(1),ACC(1));

        end
        difZ2 = max(abs(Z_tensor(:) - z_t(:)));
        if iter_2>1
            error(iter_2-1) = difZ2;
        end
        if difZ2 < tol2 && iter_2 >=2
            break;
        end
        fprintf('outside loop:iter_2 = %d, difZ = %.3f,err=%d\n'...
            , iter_2,difZ,difZ2);
        mu = mu_t;
        iter_2 = iter_2 + 1;
    end
    z_tensor_final = tensor(Z_tensor);
    Y_Tucker = tucker_als(z_tensor_final,[data_num,data_num,1]);
    B = Y_Tucker.core;
    U = Y_Tucker.U{1};
    V = Y_Tucker.U{2};
    W = Y_Tucker.U{3};
    G = double(ttm(B,{U V},[1 2 ]));

    [pi,~]=eigs(G,1);                 %largest eigenvector
    Dist=pi/sum(pi);
    pi=diag(Dist);                    %L'
    P_hat=(pi^0.5*G*pi^-0.5+pi^-0.5*G'*pi^0.5)/2;

    % toc
     fprintf(data_name)
%     [V,Eval,F,P,R,nmi,avgent,AR,ACC,C] = baseline_spectral_onRW_acc(P_hat,numClust,gt,projev);
%     fprintf('lambda=%f, F=%f, P=%f, R=%f, nmi score=%f, avgent=%f,  AR=%f, ACC=%f,\n',lambda,F(1),P(1),R(1),nmi(1),avgent(1),AR(1),ACC(1));
% 
%     %%
%     [pred, C] = kmeans(P_hat, numClust);
%     [F P R nmi avgent AR ACC] = baseline_acc(pred,gt);
%     fprintf('ELMSC keamns: F=%f, P=%f, R=%f, nmi score=%f, avgent=%f,  AR=%f, ACC=%f,\n',F(1),P(1),R(1),nmi(1),avgent(1),AR(1),ACC(1));
    [pred] = SpectralClustering(P_hat, numClust);
    [F P R nmi avgent AR ACC] = baseline_acc(pred,gt);
    fprintf('ELMSC spectralClustering  :F=%f, P=%f, R=%f, nmi score=%f, avgent=%f,  AR=%f, ACC=%f,\n',F(1),P(1),R(1),nmi(1),avgent(1),AR(1),ACC(1));
    end

