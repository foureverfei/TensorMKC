clear;clc;
it = 1;
%%

dataset_box = {'USPS'};
lambda_box = [0.01];
beta_box =[0.001];
iter_num =50;
for dataset_index = 1:length(dataset_box)
    dataset_name = cell2mat(dataset_box(dataset_index));
    dataset_file = strcat(dataset_name, '.mat');
    load(dataset_file);
    X1=X;
    data = X1;
    gt =Y;
    %F =[];P=[];R=[];nmi=[];avgent=[];AR=[];ACC=[];Beta=[];Lambda=[];
    
    num_cluster = length(unique(gt));
    REPlic = 20; % Number of replications for KMeans
    MAXiter = 1000; % Maximum number of iterations for KMeans
    m = size(gt,1);
    %it = it+1;   
    opts.lambda =lambda_box(dataset_index);
    opts.beta = beta_box(dataset_index);
    opts.projev =1.5;
    [F_B(it) P_B(it) R_B(it) nmi_B(it) avgent_B(it) AR_B(it) ACC_B(it) P_hat_B error_B ~] = func_diffM_Tensor_Tucker_B(data,gt,dataset_name,opts);
    for it = 1:iter_num
        [pred_B] = SpectralClustering(P_hat_B, num_cluster);
        [F_B(it) P_B(it) R_B(it) nmi_B(it) avgent_B(it) AR_B(it) ACC_B(it)] = baseline_acc(pred_B,gt);
    end
    method_name(1) = string(strcat(dataset_name, '_Core'));
    Beta(1) = beta_box(1);
    Lambda(1) = lambda_box(1);
    F_mean = mean(F_B); F_std = std(F_B);
    P_mean = mean(P_B); P_std = std(P_B);
    R_mean = mean(R_B); R_std = std(R_B);
    nmi_mean = mean(nmi_B); nmi_std = std(nmi_B);
    avgent_mean = mean(avgent_B); avgent_std = std(avgent_B);
    AR_mean = mean(AR_B); AR_std = std(AR_B);
    ACC_mean = mean(ACC_B); ACC_std = std(ACC_B);
    finale_result_1 = [method_name,Beta,Lambda,ACC_mean,nmi_mean,AR_mean,F_mean,P_mean,R_mean,avgent_mean;method_name,Beta,Lambda,ACC_std,nmi_std,AR_std,F_std,P_std,R_std,avgent_std];
    disp(finale_result_1);
    %%
   
    save_path_name = strcat('D:\Work\Matlab_Code\CATFAT\CATFAT\results\std\embedding_',dataset_file);    
    save(save_path_name);
    save_path = 'D:\Work\Matlab_Code\CATFAT\CATFAT\results\std\';
    xlswrite(string(save_path)+'_Mean_diff_metric_Tucker_ELSTMC_'+dataset_name+'_meanstd.xls', finale_result_1);
    
end
