clear;clc;
it = 1;
load('GLI_85_embedding');

figure((dataset_index-1)*3+1);
X = tsne(data);
scatter(X(gt==1,1),X(gt==1,2),'filled','R');
hold on;
scatter(X(gt==2,1),X(gt==2,2),'filled','B');
hold off;


N = size(data,1);
cls_num = 2;
[uN_SC,sN_SC,vN_SC] = svd(L_hat_2);
kerN_SC = vN_SC(:,N-cls_num+1:N);
kerNS_SC = zeros(size(kerN_SC));
for i = 1:N
    kerNS_SC(i,:) = kerN_SC(i,:) ./ norm(kerN_SC(i,:)+eps);
end
figure((dataset_index-1)*3+2);
X_SC = tsne(kerNS_SC);
%scatter(X_SC(:,1),X_SC(:,2),'filled','cdata',gt);
scatter(X_SC(gt==1,1),X_SC(gt==1,2),'filled','R');
hold on;
scatter(X_SC(gt==2,1),X_SC(gt==2,2),'filled','B');
hold off;
DN = diag( 1./sqrt(sum(P_hat)+eps) );
LapN = speye(N) - DN * P_hat * DN;
[uN,sN,vN] = svd(LapN);
kerN = vN(:,N-cls_num+1:N);
kerNS = zeros(size(kerN));
for i = 1:N
    kerNS(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
end
figure((dataset_index-1)*3+3);
X_TUCKer = tsne(kerNS);
scatter(X_TUCKer(gt==1,1),X_TUCKer(gt==1,2),'filled','R');
hold on;
scatter(X_TUCKer(gt==2,1),X_TUCKer(gt==2,2),'filled','B');
hold off;