%%ss
clear;clc;
it = 1;
%%
% dataset='DataYaleB2421.mat';
% data_name = 'YaleB';
% load(dataset);
% 
% alldata = NormalizeFea(alldata,1);
% X1=alldata';
% data = X1;
% gt = true_gt';
% method_name(it) = "DataYaleB2421";
% 
% lambda_box = [0.01,0.02,0.03,0.04,0.05, 0.06,0.07,0.08,0.09];
% for i = 1:length(lambda_box)
%     opts.lambda = lambda_box(i);
%     opts.projev =1.5;
%     lambda(it) = opts.lambda;
%     [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
%     %keamn
%     it = it +1;
% end
% num_cluster = length(unique(gt));
% REPlic = 20; % Number of replications for KMeans
% MAXiter = 1000; % Maximum number of iterations for KMeans
% groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
% method_name(it) = "DataYaleB2421_Kmeans";
% lambda(it) = 1;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
% %SC
% m = size(gt,1);
% it = it+1;
% L_2 = similarity_matrix(data);
% L_2 = (L_2+L_2')/2;
% L_hat_2 = eye(m)-L_2;
% method_name(it) = "DataYaleB2421_EigenVector";
% lambda(it) = 1;
% [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
% finale_result = [method_name',lambda',ACC',nmi',AR',F',P',R',avgent'];
% disp(finale_result);
%%
dataset='bbcsport_2view.mat';
data_name = 'bbc';
load(dataset);
X1=data{1};
data = X1;
gt = truth;
opts.lambda = 0.038;
opts.projev =1.5;
opts.beta = 0.01;
method_name(it) = "bbc";
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keamn
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "bbc_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "bbc_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);



%%
it = it+1;
dataset='F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\dataset\yale.mat';
data_name = 'yale';
load(dataset);
X1 = X{1};
data = X1';
opts.lambda = 0.08;
opts.projev = 1.5;
opts.beta = 0.01;
method_name(it) = "yale";
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "yale_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "yale_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);


finale_result = [method_name',lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);

%%

dataset='Jaffe_32.mat';
data_name = 'Jaffe';
load(dataset);
gt=true_gt';
data = alldata';

opts.lambda = 0.03;
opts.projev = 1.5;
opts.beta = 0.01;
it = it+1;
method_name(it) = 'Jaffe';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "Jaffe_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "Jaffe_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);





%%

dataset='COIL20_3VIEWS.mat';
data_name = 'COil';
load(dataset);
gt=Y;
clear Y
data = X1;

opts.lambda = 0.005;
opts.projev = 1.5;
opts.beta = 0.01;
it = it+1;
method_name(it) = 'COil';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "coil_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "COil_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);

%%

% dataset='lymphoma.mat';
% set_label = 'lymphoma_label.mat';
% data_name = 'lymphoma';
% load(dataset);
% load(set_label);
% gt=n+1;
% clear Y
% data = m;
% data = data+min(min(data));
% opts.lambda = 0.1;
% opts.projev = 1.5;
% it = it+1;
% method_name(it) = 'lymphoma';
% lambda(it) = opts.lambda;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
% 
% %keans
% it = it +1;
% num_cluster = length(unique(gt));
% REPlic = 20; % Number of replications for KMeans
% MAXiter = 1000; % Maximum number of iterations for KMeans
% groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
% method_name(it) = "lymphoma_Kmeans";
% lambda(it) = 1;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
% %sc
% m = size(gt,1);
% it = it+1;
% L_2 = similarity_matrix(data);
% L_2 = (L_2+L_2')/2;
% L_hat_2 = eye(m)-L_2;
% method_name(it) = "lymphoma_EigenVector";
% lambda(it) = 1;
% [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);



%%

dataset='uci_gene.mat';
data_name = 'UCI_gene';
load(dataset);
gt=cell2mat(Y);
data = X;

opts.lambda = 0.4;
opts.projev = 1.5;
it = it+1;
method_name(it) = 'UCI_gene';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "UCI_gene_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "UCI_gene_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);


%%


dataset='UmistData_25.mat';
data_name = 'Umist';
load(dataset);
gt=gnd;
data = data';

opts.lambda = 0.01;
opts.projev = 1.5;
it = it+1;
method_name(it) = "Umist";
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "Umist_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "Umist_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);


%%

dataset='PalmData25_uni.mat';
data_name = 'Palmdata';
load(dataset);
gt=Y;
data = X;
opts.lambda = 0.04;
opts.projev = 1.5;
it = it+1;
method_name(it) = 'Palmdata';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "Palmdata_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "Palmdata_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);

%%

dataset='MSRA25_uni.mat';
data_name = 'MSRA25';
load(dataset);
gt=Y;
data = X;
opts.lambda = 0.01;
opts.projev = 1.5;
it = it+1;
method_name(it) = 'MSRA25';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "MSRA25_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "MSRA25_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);

%%

% dataset=' F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\dataset\data\SCADI.mat';
% set_label = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\dataset\data\SCADI_label.mat';
% data_name = 'SCADI';
% 
% load(dataset);
% load(set_label);
% gt=label;
% data = A;
% opts.lambda = 0.8;
% opts.projev = 1.5;
% it = it+1;
% method_name(it) = 'SCADI';
% lambda(it) = opts.lambda;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
% 
% %keans
% it = it +1;
% num_cluster = length(unique(gt));
% REPlic = 20; % Number of replications for KMeans
% MAXiter = 1000; % Maximum number of iterations for KMeans
% groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
% method_name(it) = "SCADI_Kmeans";
% lambda(it) = 1;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
% %sc
% m = size(gt,1);
% it = it+1;
% L_2 = similarity_matrix(data);
% L_2 = (L_2+L_2')/2;
% L_hat_2 = eye(m)-L_2;
% method_name(it) = "SCADI_EigenVector";
% lambda(it) = 1;
% [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);


%%

dataset='ORLdata28_23.mat';
data_name = 'ORL';
load(dataset);
gt=true_gt';
data = alldata';
opts.lambda = 0.03;
opts.projev = 1.5;
it = it+1;
method_name(it) = 'ORL';
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);

%keans
it = it +1;
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "ORL_Kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%sc
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "ORL_EigenVector";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);


%%
finale_result = [method_name',lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);
save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
xlswrite(string(save_path)+'diff_metric_tsvd_result.xls', finale_result);
