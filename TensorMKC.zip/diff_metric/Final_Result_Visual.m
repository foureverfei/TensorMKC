%%ss
clear;clc;
it = 1;
%%

dataset_box = {'GLI_85'};
lambda_box = [0.04];
beta_box =[0.01];
iter_num =1;
for dataset_index = 1:length(dataset_box)
    dataset_name = cell2mat(dataset_box(dataset_index));
    dataset_file = strcat(dataset_name, '.mat');
    load(dataset_file);
    X1=X;
    data = X1;
    gt =Y;
    %F =[];P=[];R=[];nmi=[];avgent=[];AR=[];ACC=[];Beta=[];Lambda=[];
    
    num_cluster = length(unique(gt));
    REPlic = 20; % Number of replications for KMeans
    MAXiter = 1000; % Maximum number of iterations for KMeans
    m = size(gt,1);
    %it = it+1;
    L_2 = similarity_matrix(data);
    L_2 = (L_2+L_2')/2;
    L_hat_2 = eye(m)-L_2;
    %keamn
    groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
    %method_name(it) = string(strcat(dataset_name, '_kmeans'));
    %Beta(it) = 1;
    %Lambda(it) = 1;
    [F_kmeans(it) P_kmeans(it) R_kmeans(it) nmi_kmeans(it) avgent_kmeans(it) AR_kmeans(it) ACC_kmeans(it)] = func_ClusterMeasure(groups, gt);
    %SC
    %method_name(it) = string(strcat(dataset_name,'_SC'));
    %Beta(it) = 1;
    %Lambda(it) = 1;
    [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
    [F_SC(it) P_SC(it) R_SC(it) nmi_SC(it) avgent_SC(it) AR_SC(it) ACC_SC(it)] = func_ClusterMeasure(groups_eig, gt);
    %it = it+1;
    P_hat = {};
    for it = 1:iter_num

        
        opts.lambda =lambda_box(dataset_index);
        opts.beta = beta_box(dataset_index);
        opts.projev =1.5;
        
        %method_name(it) = string(strcat(dataset_name,'_ELSTMC'));
        %lambda(it) = opts.lambda;
        %Beta(it) = opts.beta;
        %Lambda(it) = opts.lambda;
        [F_ELSTMC(it) P_ELSTMC(it) R_ELSTMC(it) nmi_ELSTMC(it) avgent_ELSTMC(it) AR_ELSTMC(it) ACC_ELSTMC(it) P_hat] = func_diff_metric_tsvd(data,gt,dataset_name,opts);

        
        
        
        
        
        %it = it+1;
        %method_name(it) = string(strcat(dataset_name,'_TUCKER'));
        %Beta(it) = opts.beta;
        %Lambda(it) = opts.lambda;

        %it = it +1;
        
        [F_TUCKER(it) P_TUCKER(it) R_TUCKER(it) nmi_TUCKER(it) avgent_TUCKER(it) AR_TUCKER(it) ACC_TUCKER(it) P_hat error_ET] = func_diffM_Tensor_Tucker(data,gt,dataset_name,opts);
        [F_B(it) P_B(it) R_B(it) nmi_B(it) avgent_B(it) AR_B(it) ACC_B(it) P_hat error_B] = func_diffM_Tensor_Tucker_B(data,gt,dataset_name,opts);
    end
    method_name(1) = string(strcat(dataset_name, '_kmeans'));
    method_name(2) = string(strcat(dataset_name, '_SC'));
    method_name(3) = string(strcat(dataset_name, '_ELSTMC'));
    method_name(4) = string(strcat(dataset_name, '_TUCKER'));
    method_name(5) = string(strcat(dataset_name, '_Core'));
    Beta(1) = 1;Beta(2) = 1;Beta(3) = beta_box(1);Beta(4) = beta_box(1);Beta(5) = beta_box(1);
    Lambda(1) = 1;Lambda(2) = 1;Lambda(3) = lambda_box(1);Lambda(4) = lambda_box(1);Lambda(5) = lambda_box(1);
    F(1) = mean(F_kmeans); F(2) = mean(F_SC); F(3) = mean(F_ELSTMC); F(4) = mean(F_TUCKER); F(5) = mean(F_B);
    P(1) = mean(P_kmeans); P(2) = mean(P_SC); P(3) = mean(P_ELSTMC); P(4) = mean(P_TUCKER); P(5) = mean(P_B);
    R(1) = mean(R_kmeans); R(2) = mean(R_SC); R(3) = mean(R_ELSTMC); R(4) = mean(R_TUCKER); R(5) = mean(R_B);
    nmi(1) = mean(nmi_kmeans); nmi(2) = mean(nmi_SC); nmi(3) = mean(nmi_ELSTMC); nmi(4) = mean(nmi_TUCKER); nmi(5) = mean(nmi_B);
    avgent(1) = mean(avgent_kmeans); avgent(2) = mean(avgent_SC); avgent(3) = mean(avgent_ELSTMC); avgent(4) = mean(avgent_TUCKER); avgent(5) = mean(avgent_B);
    AR(1) = mean(AR_kmeans); AR(2) = mean(AR_SC); AR(3) = mean(AR_ELSTMC); AR(4) = mean(AR_TUCKER); AR(5) = mean(AR_B);
    ACC(1) = mean(ACC_kmeans); ACC(2) = mean(ACC_SC); ACC(3) = mean(ACC_ELSTMC); ACC(4) = mean(ACC_TUCKER); ACC(5) = mean(ACC_B);
    finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
    disp(finale_result);
    %%
    %visual results
    N = size(P_hat,1);
    cls_num = length(unique(gt));
    
    
    figure((dataset_index-1)*3+1);
    X = tsne(data);
    scatter(X(:,1),X(:,2),'filled','cdata',gt);
    
    
    [uN_SC,sN_SC,vN_SC] = svd(L_hat_2);
    kerN_SC = vN_SC(:,N-cls_num+1:N);
    kerNS_SC = zeros(size(kerN_SC));
    for i = 1:N
        kerNS_SC(i,:) = kerN_SC(i,:) ./ norm(kerN_SC(i,:)+eps);
    end
    figure((dataset_index-1)*3+2);
    X_SC = tsne(kerNS_SC);
    scatter(X_SC(:,1),X_SC(:,2),'filled','cdata',gt);
    

    DN = diag( 1./sqrt(sum(P_hat)+eps) );
    LapN = speye(N) - DN * P_hat * DN;
    [uN,sN,vN] = svd(LapN);
    kerN = vN(:,N-cls_num+1:N);
    kerNS = zeros(size(kerN));
    for i = 1:N
        kerNS(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
    end
    figure((dataset_index-1)*3+3);
    X_TUCKer = tsne(kerNS);
    scatter(X_TUCKer(:,1),X_TUCKer(:,2),'filled','cdata',gt);
    
    save_path_name = strcat('F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\embedding\embedding_',dataset_file);    
    save(save_path_name,'X','X_SC','X_TUCKer','gt','data','L_hat_2','P_hat');
    
    finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
    disp(finale_result);
    save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
    xlswrite(string(save_path)+'_Mean_diff_metric_Tucker_ELSTMC_'+dataset_name+'_result.xls', finale_result);
    
end











%         %P_hat = (P_hat+P_hat')/2;
%         N = size(P_hat,1);
%         DN = diag( 1./sqrt(sum(P_hat)+eps) );
%         Lap = speye(N) - DN * P_hat * DN;
%         m = size(Lap,1);
%         [ker_2,lamda_2] = eig(Lap);
%         [max_lamda,lambda_index] = mink(diag(lamda_2),num_cluster);
%         ker_N_2 = ker_2(:,lambda_index);
%         for i = 1:m
%             kerNS(i,:) = ker_N_2(i,:) ./ norm(ker_N_2(i,:)+eps);
%         end
%         P_hat = kerNS*kerNS';
%         
%         
%         
%         it2 =1;iter_num2=100;
%         for it2 = 1:iter_num2
%             %[pred] = SpectralClustering(P_hat, num_cluster);
%             [pred,~] = Eig_Lap_max(P_hat,num_cluster);
%             [F_ELSTMC(it2) P_ELSTMC(it2) R_ELSTMC(it2) nmi_ELSTMC(it2) avgent_ELSTMC(it2) AR_ELSTMC(it2) ACC_ELSTMC(it2)] = func_ClusterMeasure(pred, gt);
%             
%             
%             %[F_ELSTMC(it2) P_ELSTMC(it2) R_ELSTMC(it2) nmi_ELSTMC(it2) avgent_ELSTMC(it2) AR_ELSTMC(it2) ACC_ELSTMC(it2)] = baseline_acc(pred,gt);
%             fprintf('spectralClustering  :F=%f, P=%f, R=%f, nmi score=%f, avgent=%f,  AR=%f, ACC=%f,\n',F_ELSTMC(it2), P_ELSTMC(it2), R_ELSTMC(it2), nmi_ELSTMC(it2), avgent_ELSTMC(it2), AR_ELSTMC(it2), ACC_ELSTMC(it2));
%         end
%         