clear;clc;
dataset_box = {'GLI_85','lung','GLIOMA','TOX-171'};
for dataset_index = 1:length(dataset_box)
    dataset_name = cell2mat(dataset_box(dataset_index));
    dataset_file = strcat(dataset_name, '.mat');
    load(dataset_file);
    X1=X;
    data = X1;
    gt = Y;
    F =[];P=[];R=[];nmi=[];avgent=[];AR=[];ACC=[];Beta=[];Lambda=[];
    %keamn
    it = 1;
    num_cluster = length(unique(gt));
    REPlic = 20; % Number of replications for KMeans
    MAXiter = 1000; % Maximum number of iterations for KMeans
    groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
    method_name(it) = string(strcat(dataset_name, '_kmeans'));
    Beta(it) = 1;
    Lambda(it) = 1;
    [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
    %SC
    m = size(gt,1);
    it = it+1;
    L_2 = similarity_matrix(data);
    L_2 = (L_2+L_2')/2;
    L_hat_2 = eye(m)-L_2;
    method_name(it) = string(strcat(dataset_name,'_SC'));
    Beta(it) = 1;
    Lambda(it) = 1;
    [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
    [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
    it = it+1;
    
    %diff_SC
    method_name(it) = string(strcat(dataset_name,'_SC_DiffM'));
    Beta(it) = 1;
    Lambda(it) = 1;
    dis_method = {'Gaussian','Polynomial','PolyPlus','Linear'};
    [F_t P_t R_t nmi_t avgent_t AR_t ACC_t] = func_SCbydiffM(data,gt);
    for j = 1:4
        method_name(it) = dis_method(j);
        Beta(it) = 1;
        Lambda(it) = 1;
        F(it) = F_t(j);
        P(it) = P_t(j);
        R(it) = R_t(j);
        nmi(it) = nmi_t(j);
        avgent(it) = avgent_t(j);
        AR(it) = AR_t(j);
        ACC(it) = ACC_t(j);
        it = it+1;
    end
    finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
    disp(finale_result);
%    save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
%    xlswrite(string(save_path)+'diff_metric_SC'+dataset_name+'_result.xls', finale_result);
end

