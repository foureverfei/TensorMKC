clc;clear;
load('UmistData_25.mat');
%data = X{1}';
data = data';
for i = 1:644
    temp = data(:,i);
    data(:,i) = temp-mean(temp);
end
label = double(gnd);
m = size(data,1);
cls_num = length(unique(label));

it = 1;
knn = 5;

%%
%% Kmeans
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,cls_num,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
Method_Name(it) = "Kmeans";
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups);
it = it+1;
    
%%
L2 = similarity_matrix(data);
DN = diag( 1./sqrt(sum(L2)+eps) );
L2_hat = eye(m)-DN * L2 * DN;
DN_P = diag( 1./sum(L2)+eps );
L2_hat = eye(m) - DN_P*L2;

L2_consW = full(constructW(data));
DN = diag( 1./sqrt(sum(L2_consW)+eps) );
L2_consW_hat = eye(m) - DN * L2_consW * DN;
DN_P = diag( 1./sum(L2_consW)+eps );
L2_consW_hat = eye(m) - DN_P*L2_consW;


S_cos = squareform(1-pdist(data,'cosine'));
DN = diag( 1./sqrt(sum(S_cos)+eps) );
Lcos_hat = eye(m) - DN * S_cos * DN;
DN_P = diag( 1./sum(S_cos)+eps );
Lcos_hat = eye(m) - DN_P*S_cos;



[L_4, embedding] = computing4tensor_P(data, knn, cls_num,1);
%L4 = (L_4+L_4')/2;
embedding = (embedding'+embedding)/2;
embedding = embedding - diag(diag(embedding));


% svd & eigen
Method_Name(it) = "EigenVector";
[groups_eig,~] = Svd_Lap(L2_hat,cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups_eig);
it = it+1;

Method_Name(it) = "EigenVector_consW";
[groups_conW,~] = Svd_Lap(L2_consW_hat,cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups_conW);
it = it+1;

Method_Name(it) = "EigenVector_cosine";
[groups_cosine,~] = Svd_Lap(Lcos_hat,cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups_cosine);
it = it+1;

Method_Name(it) = "ConstructW";
[~,groups_cons,CKSym] = SpectralClustering5(data,cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups_cons);
it = it+1;

Method_Name(it) = "PPS_1"; % embedding through computing4tensor ((dij+dil+dkj+dkl)/(dik+djl) + average)
[group_pair3,~] = Eig_Lap_max(embedding, cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,group_pair3);
it = it+1;

Method_Name(it) = "IPS_1";
[groups_cosine,~] = Eig_Lap_max(embedding+CKSym,cls_num);
[ACC(it), ARI(it), F_SCORE(it), NMI(it), Purity(it)] = ClusterMeasure(label,groups_cosine);
it = it+1;



%% 
% high order affinity



%%
%disp results 
finale_result = [Method_Name',ACC',ARI',F_SCORE',NMI',Purity'];
disp(finale_result);