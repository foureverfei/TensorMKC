%%ss
clear;clc;

%%
dataset_box = { 'Gene_3000d'};
dataset_name = 'Gene_3000d';
load 151676_3000d.mat;
it = 1;
data = exp;
clear exp;
gt_cell = importdata('151676_truth.txt');
num = length(gt_cell);
gt = zeros(num,1);
temp = gt_cell{1};
temp = strsplit(temp);
gt_temp = temp{2};
switch(gt_temp)
    case 'Layer_1'
        gt(1) = 1;
    case 'Layer_2'
        gt(1) = 2;
    case 'Layer_3'
        gt(1) = 3;
    case 'Layer_4'
        gt(1) = 4;
    case 'Layer_5'
        gt(1) = 5;
    case 'Layer_6'
        gt(1) = 6;
    case 'WM'
        gt(1) = 7;
    otherwise
        gt(1) = 8;
end
for i = 1:num
    temp = gt_cell{i};
    temp = strsplit(temp);
    gt_temp = temp{2};
    switch(gt_temp)
        case 'Layer_1'
            gt(i) = 1;
        case 'Layer_2'
            gt(i) = 2;
        case 'Layer_3'
            gt(i) = 3;
        case 'Layer_4'
            gt(i) = 4;
        case 'Layer_5'
            gt(i) = 5;
        case 'Layer_6'
            gt(i) = 6;
        case 'WM'
            gt(i) = 7;
        otherwise
            gt(i) = 8;
    end
    
end

data_gt_train = [data gt];

data_gt_train(data_gt_train(:,3001)==8,:)=[];
data = data_gt_train(:,1:3000);
gt = data_gt_train(:,3001);

%lambda_box = [0.001 0.002 0.003 0.004 0.005 0.006 0.008 0.01:0.01:0.1 0.2 0.3 0.4];
% lambda_box = [0.01:0.01:0.1 0.2 0.3 0.4];
beta_box = [0.0001:0.0003:0.001 0.002:0.003:0.01 0.02:0.03:0.1];
%beta_box = [0.03,0.04];
lambda_box = [0.001 0.005 0.01 0.03 0.08 0.1 0.5 1 10 100];
lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);
%F =[];P=[];R=[];nmi=[];avgent=[];AR=[];ACC=[];Beta=[];Lambda=[];


% %keamn
% num_cluster = length(unique(gt));
% REPlic = 20; % Number of replications for KMeans
% MAXiter = 1000; % Maximum number of iterations for KMeans
% groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
% method_name(it) = string(strcat(dataset_name, '_kmeans'));
% Beta(it) = 1;
% Lambda(it) = 1;
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
% it = it+1;
% %SC
% m = size(gt,1);
% 
% L_2 = similarity_matrix(data);
% L_2 = (L_2+L_2')/2;
% L_hat_2 = eye(m)-L_2;
% method_name(it) = string(strcat(dataset_name,'_SC'));
% Beta(it) = 1;
% Lambda(it) = 1;.0

% [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
% [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
% it = it+1;

%%
for j = 2:beta_box_length
    for i = 1:lambda_box_length
        opts.lambda =lambda_box(i);
        opts.projev =1.5;
        opts.beta = beta_box(j);
        %             method_name(it) = string(strcat(dataset_name,'_ELSTMC'));
        %             lambda(it) = opts.lambda;
        %             Beta(it) = opts.beta;
        %             Lambda(it) = opts.lambda;
        %             [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,dataset_name,opts);
        %             it = it+1;
        %             method_name(it) = string(strcat(dataset_name,'_TUCKER'));
        %             Beta(it) = opts.beta;
        %             Lambda(it) = opts.lambda;
        %             [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it) P_hat error]0 = func_diffM_Tensor_Tucker(data,gt,dataset_name,opts);
        %             it = it +1;
        method_name(it) = string(strcat(dataset_name,'_CORE'));
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it) P_hat error] = func_diffM_Tensor_Tucker_B(data,gt,dataset_name,opts);
        ACC_box(i,j) = ACC(it);
        it = it +1;
        save_path_name = strcat('F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\hypergraph_Tsvd\results\',dataset_name);
        save(save_path_name);
    end
end
finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);
save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\hypergraph_Tsvd\results\';
xlswrite(string(save_path)+'diff_metric_Tucker_With_B_'+dataset_name+'_result.xls', finale_result);
save_path_name = strcat('F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\hypergraph_Tsvd\results\',dataset_name);
save(save_path_name);




