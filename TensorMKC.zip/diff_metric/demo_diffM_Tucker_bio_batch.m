%%ss
clear;clc;
it = 1;
%%
lambda_box = [0.01:0.01:0.1 0.2 0.3 0.4];
beta_box = [0.0001:0.0001:0.001 0.002:0.001:0.01 0.02:0.01:0.1];
lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);

dataset_box = {'GLIOMA'};
for dataset_index = 1:length(dataset_box)
    dataset_name = cell2mat(dataset_box(dataset_index));
    dataset_file = strcat(dataset_name, '.mat');
    load(dataset_file);
    X1=X;
    data = X1;
    gt = Y;
    F =[];P=[];R=[];nmi=[];avgent=[];AR=[];ACC=[];Beta=[];Lambda=[];
    %keamn
    num_cluster = length(unique(gt));
    REPlic = 20; % Number of replications for KMeans
    MAXiter = 1000; % Maximum number of iterations for KMeans
    groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
    method_name(it) = string(strcat(dataset_name, '_kmeans'));
    Beta(it) = 1;
    Lambda(it) = 1;
    [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
    %SC
    m = size(gt,1);
    it = it+1;
    L_2 = similarity_matrix(data);
    L_2 = (L_2+L_2')/2;
    L_hat_2 = eye(m)-L_2;
    method_name(it) = string(strcat(dataset_name,'_SC'));
    Beta(it) = 1;
    Lambda(it) = 1;
    [groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
    [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
    it = it+1;
    
    
    for i = 1:lambda_box_length
        for j = 1:beta_box_length
            opts.lambda =lambda_box(i);
            opts.projev =1.5;
            opts.beta = beta_box(j);
            method_name(it) = string(strcat(dataset_name,'_ELSTMC'));
            lambda(it) = opts.lambda;
            Beta(it) = opts.beta;
            Lambda(it) = opts.lambda;
            [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,dataset_name,opts);
            it = it+1;
            method_name(it) = string(strcat(dataset_name,'_TUCKER'));
            Beta(it) = opts.beta;
            Lambda(it) = opts.lambda;
            [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it) P_hat] = func_diffM_Tensor_Tucker(data,gt,dataset_name,opts);
            it = it +1;
        end
    end
    finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
    disp(finale_result);
    save_path = 'D:\Work\Matlab_Code\CATFAT\CATFAT\results\';
    xlswrite(string(save_path)+'diff_metric_Tucker_ELSTMC_'+dataset_name+'_result.xls', finale_result);
    
end

