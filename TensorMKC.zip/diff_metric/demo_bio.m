%%ss
clear;clc;
it = 1;
%%
dataset='TOX-171.mat';
data_name = 'TOX-171';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "TOX-171_keanms";
Beta(it) = 1;
Lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "TOX-171_SC";
Beta(it) = 1;
Lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;


lambda_box = [0.001:0.001:0.01 0.02:0.01:0.1 ];
beta_box = [0.0001:0.0001:0.001 0.002:0.001:0.01 0.02 0.03 0.04];
lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);

for i = 1:lambda_box_length
    for j = 1:beta_box_length
        opts.lambda =lambda_box(i);
        opts.projev =1.5;
        opts.beta = beta_box(j);
        method_name(it) = "TOX-171_ELSTMC";
        lambda(it) = opts.lambda;
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
        it = it+1;
        method_name(it) = "TOX-171_TUCKER";
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
        it = it +1;
    end
end
finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);
save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
xlswrite(string(save_path)+'diff_metric_Tucker_TOX-171_ELSTMC_result.xls', finale_result);



%%
dataset='warpAR10P.mat';
data_name = 'warpAR10P';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "warpAR10P_keanms";
Beta(it) = 1;
Lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "warpAR10P_SC";
Beta(it) = 1;
Lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;


lambda_box = [0.001:0.001:0.01 0.02:0.01:0.1 ];
beta_box = [0.0001:0.0001:0.001 0.002:0.001:0.01 0.02 0.03 0.04];
lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);

for i = 1:lambda_box_length
    for j = 1:beta_box_length
        opts.lambda =lambda_box(i);
        opts.projev =1.5;
        opts.beta = beta_box(j);
        method_name(it) = "warpAR10P_ELSTMC";
        lambda(it) = opts.lambda;
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
        it = it+1;
        method_name(it) = "warpAR10P_TUCKER";
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
        it = it +1;
    end
end
finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);
save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
xlswrite(string(save_path)+'diff_metric_Tucker_warpAR10P_ELSTMC_result.xls', finale_result);



%%
dataset='GLIOMA.mat';
data_name = 'GLIOMA';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "GLIOMA_keanms";
Beta(it) = 1;
Lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "GLIOMA_SC";
Beta(it) = 1;
Lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;


lambda_box = [0.001:0.001:0.01 0.02:0.01:0.1 ];
beta_box = [0.0001:0.0001:0.001 0.002:0.001:0.01 0.02 0.03 0.04];
lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);

for i = 1:lambda_box_length
    for j = 1:beta_box_length
        opts.lambda =lambda_box(i);
        opts.projev =1.5;
        opts.beta = beta_box(j);
        method_name(it) = "GLIOMA_ELSTMC";
        lambda(it) = opts.lambda;
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
        it = it+1;
        method_name(it) = "GLIOMA_TUCKER";
        Beta(it) = opts.beta;
        Lambda(it) = opts.lambda;
        [F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
        it = it +1;
    end
end
finale_result = [method_name',Beta',Lambda',ACC',nmi',AR',F',P',R',avgent'];
disp(finale_result);
save_path = 'F:\Work\Tensor Clustering\Tensor Spectral Clustering\high_order\affinies_orders_v2_0815\hypergraph_TSVD\hypergraph_Tsvd\results\';
xlswrite(string(save_path)+'diff_metric_Tucker_GLIOMA_ELSTMC_result.xls', finale_result);
%%
dataset='GLIOMA.mat';
data_name = 'GLIOMA';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "GLIOMA_keanms";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "GLIOMA_SC";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;


opts.lambda = 0.08;
opts.projev =1.5;
opts.beta = 0.001;
method_name(it) = "GLIOMA_ELSTMC";
lambda(it) = opts.lambda;
Beta(it) = opts.beta;
Lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
method_name(it) = "GLIOMA_TUCKER";
Beta(it) = opts.beta;
Lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
it = it +1;

%%
dataset='lung.mat';
data_name = 'lung';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "lung_kmeans";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "lung_SC";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;
opts.lambda = 0.038;
opts.projev =1.5;
opts.beta = 0.03;
method_name(it) = "lung_ELSTMC";
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
method_name(it) = "lung_TUCKER";
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
it = it +1;


%%
dataset='TOX-171.mat';
data_name = 'TOX-171';
load(dataset);
X1=X;
data = X1;
gt = Y;

%keamn
num_cluster = length(unique(gt));
REPlic = 20; % Number of replications for KMeans
MAXiter = 1000; % Maximum number of iterations for KMeans
groups = kmeans(data,num_cluster,'maxiter',MAXiter,'replicates',REPlic,'EmptyAction','singleton');
method_name(it) = "TOX-171_keanms";
lambda(it) = 1;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups, gt);
%SC
m = size(gt,1);
it = it+1;
L_2 = similarity_matrix(data);
L_2 = (L_2+L_2')/2;
L_hat_2 = eye(m)-L_2;
method_name(it) = "TOX-171_SC";
lambda(it) = 1;
[groups_eig,~] = Eig_Lap(L_hat_2,num_cluster);
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_ClusterMeasure(groups_eig, gt);
it = it+1;
opts.lambda = 0.038;
opts.projev =1.5;
opts.beta = 0.03;
method_name(it) = "TOX-171_ELSTMC";
lambda(it) = opts.lambda;
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diff_metric_tsvd(data,gt,data_name,opts);
it = it+1;
method_name(it) = "TOX-171_TUCKER";
[F(it) P(it) R(it) nmi(it) avgent(it) AR(it) ACC(it)] = func_diffM_Tensor_Tucker(data,gt,data_name,opts);
it = it +1;




