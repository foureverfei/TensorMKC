 %%ss
clear;clc;
it = 1;
%%
dataset_box = { 'YaleO'};

lambda_box = [0.04];
beta_box = [0.01];

lambda_box_length = size(lambda_box,2);
beta_box_length = size(beta_box,2);
for dataset_index = 1:length(dataset_box)
    dataset_name = cell2mat(dataset_box(dataset_index));
    dataset_file = strcat(dataset_name, '.mat');
    load(dataset_file);
    data = X;
    gt = Y;
    %keamn
    num_cluster = length(unique(gt));
    num_sample = size(gt,1);
    method_name = string(strcat('MKTC_',dataset_name));
    ratio = 1;
    opt.sigma=ratio*optSigma(data);
    opt.lambda_box = lambda_box;
    opt.beta_box = beta_box;
    opt.kernel_box = {'Gaussian','Polynomial','PolyPlus','Linear'};
    finale_result = func_MKTC(data,gt,opt);
    disp(finale_result);
    save_path = 'F:\Work\Matlab_Code\CATFAT\realease\CATFAT\results\';
    xlswrite(string(save_path)+'diff_metric_Tucker_With_B_'+dataset_name+'_result.xls', finale_result);
    save_path_name = strcat('F:\Work\Matlab_Code\CATFAT\realease\CATFAT\results\',method_name);
    save(save_path_name);
end



