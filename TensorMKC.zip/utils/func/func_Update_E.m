function E_tensor = func_Update_E(F,mu,lambda,sX)
%FUNC_UPDATE_E 此处显示有关此函数的摘要
%   此处显示详细说明
    mu_inv = 1/mu;
    n = sX(1);
    k = sX(3);
    F_t = zeros(n*k,n);
    for i = 1:k
        F_t(1+(i-1)*n:i*n,:) = F(:,:,i);
    end
    clear F
    [Econcat] = solve_l1l2(F_t,lambda*mu_inv);
    E_tensor = zeros(n,n,k);
    for i = 1:k
        E_tensor(:,:,i) = Econcat(1+(i-1)*n:i*n,:);
    end
end

