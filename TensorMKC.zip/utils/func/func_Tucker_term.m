function G = func_Tucker_term(Z_tensor,num_sample)
%FUNC_TUCKER_TERM 此处显示有关此函数的摘要
%   此处显示详细说明
    z_tensor_2 = tensor(Z_tensor);
    Y_Tucker = tucker_als(z_tensor_2,[num_sample,num_sample,1]);
    U1 = Y_Tucker.U{1};
    U2 = Y_Tucker.U{2};
    U3 = Y_Tucker.U{3};
    G = double(ttm(Y_Tucker.core,{U1 U2 U3},[1 2 3]));
end

