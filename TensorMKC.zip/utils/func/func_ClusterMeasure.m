function [F P R nmi avgent AR ACC] = func_ClusterMeasure(truth, label)
%FUNC_CLUSTERMEASURE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [F,P,R] = compute_f(truth,label);
    ACC = Accuracy(label,double(truth));
    [A nmi avgent] = compute_nmi(truth,label);
    if (min(truth)==0)
        [AR,RI,MI,HI]=RandIndex(truth+1,label);
    else
        [AR,RI,MI,HI]=RandIndex(truth,label);
    end
end

