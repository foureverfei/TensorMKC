function Z_tensor = func_Update_T(Temp,mu,sX)
%FUNC_UPDATE_Z 此处显示有关此函数的摘要
%   此处显示详细说明
    Temp = Temp(:);
    [z, ~] = wshrinkObj(Temp,1/mu,sX,0,3);
    Z_tensor = reshape(z, sX);
end

