function [pred] = func_solver_MKTC(T, gt, opt)
%FUNC_SOLVER_MKTC 此处显示有关此函数的摘要
%   此处显示详细说明
    defaultOpts.lambda = 1;
    defaultOpts.beta = 1;
    opt = checkOptions(opt, defaultOpts);
    lambda = opt.lambda;
    beta = opt.beta;
    T_tensor = cat(3, T{:,:}); % T_tensor: K n*n*k
    num_sample = size(T_tensor,1);
    num_kernel = length(T);
    num_cluster = length(unique(gt));
    t = T_tensor(:);

    %% init evaluation result
    Z_tensor = zeros(num_sample,num_sample,num_kernel);
    E_tensor = zeros(num_sample,num_sample,num_kernel);
    Y_tensor = zeros(num_sample,num_sample,num_kernel);

    %initial Setting
    sX = [num_sample, num_sample, num_kernel];
    tol = 1e-6;
    tol2=1e-7;
    iter = 0;
    mu = 10e-3;
    max_mu = 10e10;
    pho_mu = 2;
    max_iter=200;
    iter_2 = 0;
    max_iter_2 = 50;
    eplison = 1e-5;
    mu_t = mu;
    while iter_2 < max_iter_2
        fprintf('----processing iter %d--------\n', iter_2+1);
        if iter_2 == 0
            while iter < max_iter
                Z_tensor_pre=Z_tensor;
                E_tensor_pre=E_tensor;
                mu_inv = 1/mu;
                %% update Z
                %Y_tensor = cat(3, Y{:,:});
                Temp = T_tensor-E_tensor+mu_inv*Y_tensor;
                Z_tensor = func_Update_T(Temp,mu,sX);
                clear Temp
                %% update E
                Temp = T_tensor-Z_tensor+Y_tensor*mu_inv;
                E_tensor = func_Update_E(Temp,mu,lambda,sX);
                clear Temp
                %% update Y
                Y_tensor = Y_tensor + mu*(T_tensor-Z_tensor-E_tensor);
                %% check convergence
                leq = T_tensor-Z_tensor-E_tensor;
                leqm = max(abs(leq(:)));
                difZ = max(abs(Z_tensor(:)-Z_tensor_pre(:)));
                difE = max(abs(E_tensor(:)-E_tensor_pre(:)));
                err = max([leqm,difZ,difE]);
                if err < tol
                    break;
                end
                iter = iter + 1;
                mu = min(mu*pho_mu, max_mu);
            end
            iter_2 = iter_2 + 1;
            continue;
        else
            %%perform Tucker fusion term
            z_t = Z_tensor;
            G = func_Tucker_term(tensor(Z_tensor),num_sample);
            g = G(:);
            clear G 
        end
        iter = 1;
        while iter < max_iter
            Z_tensor_pre=Z_tensor;
            E_tensor_pre=E_tensor;
            %% update Z
            y = Y_tensor(:);
            e = E_tensor(:);
            Temp = (mu*(t-e+1/mu*y)+beta*g)/(mu+beta); 
            tlambda = mu+beta;
            Z_tensor = func_Update_T(Temp,tlambda,sX);
            clear Temp y e
            %% update E
            mu_inv = 1/mu;
            Temp = T_tensor-Z_tensor+Y_tensor*mu_inv;
            E_tensor = func_Update_E(Temp,mu,lambda,sX);
            clear Temp 
            %% update Y
            Y_tensor = Y_tensor + mu*(T_tensor-Z_tensor-E_tensor);
            %% check convergence
            leq = T_tensor-Z_tensor-E_tensor;
            leqm = max(abs(leq(:)));
            difZ = max(abs(Z_tensor(:)-Z_tensor_pre(:)));
            difE = max(abs(E_tensor(:)-E_tensor_pre(:)));
            err = max([leqm,difZ,difE]);
            if err < tol
                break;
            end
            iter = iter + 1;
            mu = min(mu*pho_mu, max_mu);
        end
        difZ2 = max(abs(Z_tensor(:) - z_t(:)));
        if iter_2>1
            error(iter_2-1) = difZ2;
        end
        if difZ2 < tol2 && iter_2 >=2
            break;
        end
        fprintf('outside loop:iter_2 = %d, difZ = %.3f,err=%d\n'...
            , iter_2,difZ,difZ2);
        mu = mu_t;
        iter_2 = iter_2 + 1;
    end
    Y_Tucker = tucker_als(tensor(Z_tensor),[num_sample,num_sample,1]);
    B = Y_Tucker.core;
    U = Y_Tucker.U{1};
    V = Y_Tucker.U{2};
    %W = Y_Tucker.U{3};
    G = double(ttm(B,{U V},[1 2 ]));

    [pi,~]=eigs(G,1);                 %largest eigenvector
    Dist=pi/sum(pi);
    pi=diag(Dist);                    %L'
    P_hat=(pi^0.5*G*pi^-0.5+pi^-0.5*G'*pi^0.5)/2;
    affinity_mat = P_hat;
    DN = diag( 1./sqrt(sum(affinity_mat)+eps) );
    LapN = speye(num_sample) - DN * affinity_mat * DN;
    [~,~,vN] = svd(LapN);
    kerN = vN(:,num_sample-num_cluster+1:num_sample);
    for i = 1:num_sample
        kerNS(i,:) = kerN(i,:) ./ norm(kerN(i,:)+eps);
    end
    affinity_mat = kerNS*kerNS';
    [pred] = SpectralClustering(affinity_mat, num_cluster);

end

