function [Kernel_Tensor] = func_cons_mk_tensor(data,opt)
%FUNC_CONS_MK_TENSOR 此处显示有关此函数的摘要
%   此处显示详细说明
%%Initial setup
    defaultOpts.sigma=1;
    defaultOpts.lambda_box = {1};
    defaultOpts.beta_box = {1};
    defaultOpts.kernel_box = {'Gaussian','Polynomial','PolyPlus','Linear'};
    opt = checkOptions(opt, defaultOpts);
    sigma = opt.sigma; 
    kernel_box = opt.kernel_box;
    clear opt defaultOpts

    num_kernel = length(kernel_box);
    num_sample = size(data,1);
%% Construct Multi_kernel Tensor
    Kernel_Tensor=zeros(num_sample,num_sample,num_kernel);
    K = zeros(num_sample,num_sample,num_kernel);
    for j=1:num_kernel
        options.KernelType = kernel_box{j};
        options.t = sigma;
        options.d = 2;
        K(:,:,j) = constructKernel(data,data,options);
        D=diag(sum(K(:,:,j),2));
        L_rw=D^-1*K(:,:,j);
        Kernel_Tensor(:,:,j)=L_rw;
    end
end

