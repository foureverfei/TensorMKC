function opt = checkOptions(opt, defaultOpts)
    fields = fieldnames(defaultOpts);
    for i = 1:numel(fields)
        if ~isfield(opt, fields{i})
            opt.(fields{i}) = defaultOpts.(fields{i});
        end
    end
end