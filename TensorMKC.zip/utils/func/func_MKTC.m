function [finale_result] = func_MKTC(data,gt,opt)
%FUNC_DIFFM_TENSOR_TUCKER solve the MKTC problem
%
%%Initial setup
    defaultOpts.sigma=1;
    defaultOpts.lambda_box = {1};
    defaultOpts.beta_box = {1};
    defaultOpts.kernel_box = {'Gaussian','Polynomial','PolyPlus','Linear'};
    opt = checkOptions(opt, defaultOpts);
    sigma = opt.sigma; 
    lambda_box = opt.lambda_box;
    beta_box = opt.beta_box;
    kernel_box = opt.kernel_box;
    clear opt defaultOpts

    num_kernel = length(kernel_box);
    lambda_box_length = length(lambda_box);
    beta_box_length = length(beta_box);
    num_sample = length(gt);
%% Construct Multi_kernel Tensor
    Kernel_Tensor=cell(1,num_kernel);
    K = zeros(num_sample,num_sample,num_kernel);
    for j=1:num_kernel
        options.KernelType = kernel_box{j};
        options.t = sigma;
        options.d = 2;
        K(:,:,j) = constructKernel(data,data,options);
        D=diag(sum(K(:,:,j),2));
        L_rw=D^-1*K(:,:,j);
        Kernel_Tensor{j}=L_rw;
    end
    clear K D L_rw;
%%Grid Search for the optimal parameter(\lambda & \beta)
    it = 1;
    num_iter = lambda_box_length*beta_box_length;
    Lambda = zeros(num_iter);
    Beta = zeros(num_iter);
    ACC = zeros(num_iter); ARI = zeros(num_iter); NMI = zeros(num_iter);
    F_Score = zeros(num_iter); Purity = zeros(num_iter);
    for i = 1:lambda_box_length
        for j = 1:beta_box_length
            opt.lambda = lambda_box(i);
            opt.beta =  beta_box(j);
            
            %% MKTC
            method_name(it) = string('MKTC');
            Lambda(it) = lambda_box(i);
            Beta(it) = beta_box(j);
            tic
            pred = func_solver_MKTC(Kernel_Tensor, gt, opt);
            time(it) = toc;
            [ACC(it), ARI(it), F_Score(it), NMI(it), Purity(it)] = ClusterMeasure(gt,pred);
            it = it+1;
        end
    end
    finale_result = [Lambda',Beta',ACC',NMI',ARI',F_Score',Purity',time'];
    disp(finale_result);
end



